# Task 01 — Hotspot and Density Analysis of Abandoned Oil & Gas Wells (Alberta)

## Starting State (Provided Inputs)

The task workspace contains exactly the following files:

- **`Abandoned_Suspended_raw.zip`** — a zipped Esri shapefile bundle containing the complete file set: `Abandoned_Suspended_raw.shp`, `.shx`, `.dbf`, `.prj`, and `.cpg`. Source CRS is EPSG:4269 (NAD83 geographic). Source feature count is 94,428.
  *(Equivalent acceptable form: `Abandoned_Suspended_raw.gpkg` containing the same features and attributes.)*
- **`reference_layout.png`** — a static image of the target QGIS print layout. **This file is visual guidance only. It is not required to execute the analysis, must not be embedded as an image inside the deliverable, and must not be included in the final zip.** Its sole purpose is to communicate the intended composition of the native QGIS print layout you will build in Step 6.

No other inputs are required or permitted.

---

## Objective

Build a fully reproducible QGIS project that identifies and communicates spatial concentrations of abandoned oil and gas wells across Alberta, supporting orphan-well risk screening, liability assessment, and decommissioning prioritization. The project must produce two complementary analytical outputs — a continuous density surface (KDE) and a discrete clustering result (DBSCAN with cluster footprints) — and package them with a styled QGIS project file and native print layout.

---

## Required Processing Steps

Execute every step exactly as specified. All numeric parameters and algorithm choices are mandatory; do not substitute defaults or alternatives.

### Step 1 — Filter and Persist Abandoned Wells
1. Extract `Abandoned_Suspended_raw.zip` (if applicable) and load `Abandoned_Suspended_raw.shp`.
2. Retain only features where `Status = 'Abandoned'`. All other status values (e.g., 'Suspension') must be excluded.
3. Persist the filtered subset to **`abandoned_wells.gpkg`** as a single Point layer.
4. Geometry type must remain Point. Feature count must equal the count of `Status = 'Abandoned'` records in the source.

### Step 2 — Reproject to Working CRS
- Reproject the filtered dataset to **EPSG:3400 — NAD83 / Alberta 10-TM Forest** (linear units = metres). This CRS is mandatory and must be applied to every analytical output produced in Steps 3–5. No alternative projection is acceptable.

### Step 3 — Kernel Density Estimation (KDE)

- **Algorithm:** `qgis:heatmapkerneldensityestimation` (or an equivalent producing identical output).

| Parameter | Required value |
|---|---|
| Input layer | `abandoned_wells.gpkg` (EPSG:3400) |
| Kernel shape | Quartic |
| Radius (bandwidth) | **10,000 m** |
| Pixel size | **1,000 m** |
| Output value | **Raw** density units (no scaling, no normalization, no 0–1 or 0–255 rescaling) |
| Output extent | **Full extent of the input layer** (no clipping to a sub-region) |
| Output CRS | EPSG:3400 |
| Output file | **`abandoned_wells_kde.tif`** (single-band float GeoTIFF) |

### Step 4 — DBSCAN Spatial Clustering

- **Algorithm:** `native:dbscanclustering` (must be DBSCAN — not OPTICS, k-means, or any other clustering method).

| Parameter | Required value |
|---|---|
| Input layer | `abandoned_wells.gpkg` (EPSG:3400) |
| Maximum distance between clustered points (eps) | **2,000 m** |
| Minimum cluster size | **50 wells** |
| Output CRS | EPSG:3400 |
| Output file | **`abandoned_wells_clusters.gpkg`** |

The output layer must contain every input well, with the following attributes added:

- **`CLUSTER_ID`** (integer): unique cluster identifier. Wells that do not satisfy both DBSCAN thresholds are noise points and must have `CLUSTER_ID` set to **NULL**.
- **`CLUSTER_SIZE`** (integer): for every clustered well, the total count of wells sharing its `CLUSTER_ID`. Must be NULL (or empty) for noise points.

### Step 5 — Cluster Footprints (Convex Hulls)

- **Algorithm:** `qgis:minimumboundinggeometry` with **Geometry Type = Convex Hull**.

| Parameter | Required value |
|---|---|
| Input layer | `abandoned_wells_clusters.gpkg` filtered to non-noise points (`CLUSTER_ID IS NOT NULL`) |
| Group-by field | `CLUSTER_ID` |
| Output CRS | EPSG:3400 |
| Output file | **`cluster_hulls.gpkg`** |

Each output polygon represents one cluster's spatial footprint and must carry the `CLUSTER_ID` attribute (and may also carry `CLUSTER_SIZE`) so that hulls can be joined back to the wells in `abandoned_wells_clusters.gpkg`. Polygon count must equal the number of distinct non-NULL cluster IDs.

### Step 6 — QGIS Project Assembly

Create **`01_Hotspot_Density_Analysis.qgz`** containing all four data layers above, with:

1. **Layer organization:** layers grouped in the Layers panel (e.g., `Input`, `Density`, `Clusters`) with descriptive layer names.
2. **Symbology:** non-default styling applied to each layer:
   - KDE raster: continuous color ramp.
   - Cluster points: colored or graduated by `CLUSTER_SIZE` (or `CLUSTER_ID`); noise points clearly distinguished.
   - Cluster hulls: semi-transparent fill with visible outline.
3. **Native print layout:** a layout opened from the Layouts panel (not an embedded image) reproducing the composition shown in `reference_layout.png`. The layout must include at minimum:
   - Title
   - Map frame (KDE + clusters + hulls visible)
   - Legend
   - Scale bar
   - North arrow

### Step 7 — Packaging and Portability

Bundle the deliverable as **`01_Hotspot_Density_Analysis.zip`** containing exactly these five files at the root (no subfolders required, no additional files):

```
01_Hotspot_Density_Analysis.zip
├── 01_Hotspot_Density_Analysis.qgz
├── abandoned_wells.gpkg
├── abandoned_wells_kde.tif
├── abandoned_wells_clusters.gpkg
└── cluster_hulls.gpkg
```

**Mandatory project portability requirements** (every requirement is in scope for grading):

1. **No broken links.** The `.qgz` must open in a clean QGIS environment with no missing-source warnings and no manual repathing required.
2. **Relative paths only.** All `<datasource>` entries inside the `.qgz` must reference layers using paths relative to the project file (e.g., `./abandoned_wells.gpkg`). Absolute paths from the author's filesystem (e.g., `C:/Users/...`, `/home/...`, `/Users/...`) are not permitted.
3. **Self-contained.** Every layer referenced by the project must be present inside the zip at the location the project expects.
4. **Excluded from the zip:** the raw shapefile bundle (`Abandoned_Suspended_raw.*`) and `reference_layout.png`. Only the five files listed above belong in the deliverable.
5. **Native layout retained.** The print layout must remain editable inside the project (not flattened to an image).

---

## Out of Scope

The following are explicitly **not** required:

- Inclusion of the raw shapefile in the deliverable.
- Inclusion of `reference_layout.png` in the deliverable.
- Documentation, readme, or methodology files inside the zip.
- Cluster footprints other than convex hulls (e.g., concave hulls / alpha shapes).
- Any analysis of `Status = 'Suspension'` wells.
